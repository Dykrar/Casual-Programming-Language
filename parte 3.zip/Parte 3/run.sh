#!/bin/sh
python3 projeto2.py $1